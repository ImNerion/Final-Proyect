# ClimateAction

Python + Flask climate-action web app.

Features:
- Simple username registration (no email/password verification)
- Saved progress with SQLite
- English / Spanish switch
- Random environmental tasks
- XP and levels
- Profile
- Climate information
- Modern dark interface
- No JavaScript

## Run

```bash
python -m venv venv
venv\Scripts\activate
pip install flask
python app.py
```

Then open http://127.0.0.1:5000
