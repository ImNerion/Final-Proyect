from flask import Flask, render_template, redirect, url_for, session, request
import sqlite3, random
from pathlib import Path

app = Flask(__name__)
app.secret_key = "climate-action-secret-key"
DB_PATH = Path(__file__).parent / "database.db"

TASKS = [
{"id":1,"name_en":"Recycle your waste","name_es":"Recicla tus residuos","category_en":"Recycling","category_es":"Reciclaje","points":15,"how_en":"Separate paper, cardboard, plastic, glass and metal when possible.","how_es":"Separa papel, cartón, plástico, vidrio y metal cuando sea posible.","benefit_en":"Recycling reduces waste and saves raw materials.","benefit_es":"Reciclar reduce los residuos y ahorra materias primas."},
{"id":2,"name_en":"Save water","name_es":"Ahorra agua","category_en":"Water","category_es":"Agua","points":10,"how_en":"Turn off the tap while brushing your teeth.","how_es":"Cierra el grifo mientras te cepillas los dientes.","benefit_en":"Using less water helps conserve an essential natural resource.","benefit_es":"Usar menos agua ayuda a conservar un recurso natural esencial."},
{"id":3,"name_en":"Use public transportation","name_es":"Usa el transporte público","category_en":"Transportation","category_es":"Transporte","points":20,"how_en":"For a suitable trip, choose public transportation instead of a private car.","how_es":"Para un viaje adecuado, elige transporte público en lugar de un auto particular.","benefit_en":"Shared transportation can reduce fuel use and emissions per person.","benefit_es":"Compartir el transporte puede reducir el uso de combustible y las emisiones por persona."},
{"id":4,"name_en":"Walk or ride a bicycle","name_es":"Camina o usa bicicleta","category_en":"Transportation","category_es":"Transporte","points":20,"how_en":"For a short and safe trip, walk or ride a bicycle.","how_es":"Para un viaje corto y seguro, camina o usa una bicicleta.","benefit_en":"Walking and cycling do not require fuel.","benefit_es":"Caminar y andar en bicicleta no requieren combustible."},
{"id":5,"name_en":"Turn off unnecessary lights","name_es":"Apaga las luces innecesarias","category_en":"Energy","category_es":"Energía","points":10,"how_en":"Turn off lights when you leave a room and they are not needed.","how_es":"Apaga las luces cuando salgas de una habitación y no sean necesarias.","benefit_en":"Reducing electricity use can lower energy demand.","benefit_es":"Reducir el consumo eléctrico puede disminuir la demanda de energía."},
{"id":6,"name_en":"Unplug unused devices","name_es":"Desenchufa dispositivos que no uses","category_en":"Energy","category_es":"Energía","points":10,"how_en":"Unplug chargers and devices that are not being used when practical.","how_es":"Desenchufa cargadores y dispositivos que no estés usando cuando sea posible.","benefit_en":"Avoiding unnecessary standby consumption can save electricity.","benefit_es":"Evitar el consumo innecesario en espera puede ahorrar electricidad."},
{"id":7,"name_en":"Avoid food waste","name_es":"Evita desperdiciar comida","category_en":"Food","category_es":"Alimentación","points":15,"how_en":"Serve reasonable portions and save suitable leftovers.","how_es":"Sirve porciones razonables y guarda los restos adecuados.","benefit_en":"Wasting less food saves land, water and energy.","benefit_es":"Desperdiciar menos comida ahorra tierra, agua y energía."},
{"id":8,"name_en":"Use a reusable bottle","name_es":"Usa una botella reutilizable","category_en":"Waste","category_es":"Residuos","points":10,"how_en":"Carry a reusable bottle and refill it.","how_es":"Lleva una botella reutilizable y rellénala.","benefit_en":"Reusable items can reduce single-use waste.","benefit_es":"Los objetos reutilizables pueden reducir los residuos de un solo uso."},
{"id":9,"name_en":"Plant or care for a plant","name_es":"Planta o cuida una planta","category_en":"Nature","category_es":"Naturaleza","points":20,"how_en":"Plant something suitable for your space or care for an existing plant.","how_es":"Planta algo adecuado para tu espacio o cuida una planta que ya tengas.","benefit_en":"Plants support local ecosystems.","benefit_es":"Las plantas ayudan a los ecosistemas locales."},
{"id":10,"name_en":"Choose reusable bags","name_es":"Elige bolsas reutilizables","category_en":"Waste","category_es":"Residuos","points":10,"how_en":"Take a reusable bag when shopping.","how_es":"Lleva una bolsa reutilizable al hacer compras.","benefit_en":"Reusable bags can reduce single-use plastic waste.","benefit_es":"Las bolsas reutilizables pueden reducir los residuos de plástico de un solo uso."}
]

LEVELS=[(0,"Seedling","Semilla"),(100,"Eco Learner","Aprendiz Eco"),(250,"Green Explorer","Explorador Verde"),(500,"Eco Expert","Experto Eco"),(1000,"Planet Protector","Protector del Planeta"),(2000,"Planet Guardian","Guardián del Planeta")]

def db():
    c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; return c

def init_db():
    c=db()
    c.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, points INTEGER DEFAULT 0, completed_tasks INTEGER DEFAULT 0)")
    c.execute("CREATE TABLE IF NOT EXISTS completed_tasks (user_id INTEGER, task_id INTEGER, PRIMARY KEY(user_id,task_id))")
    c.commit(); c.close()

def user():
    name=session.get("username")
    if not name:return None
    c=db(); u=c.execute("SELECT * FROM users WHERE username=?",(name,)).fetchone(); c.close(); return u

def completed(uid):
    c=db(); r=c.execute("SELECT task_id FROM completed_tasks WHERE user_id=?",(uid,)).fetchall(); c.close(); return {x["task_id"] for x in r}

def level(points):
    cur=LEVELS[0]
    for x in LEVELS:
        if points>=x[0]:cur=x
    return cur

def next_level(points):
    for x in LEVELS:
        if points<x[0]:return x
    return None

def progress(points):
    n=next_level(points)
    if not n:return 100
    cur=level(points)[0]
    return int((points-cur)/(n[0]-cur)*100)

@app.context_processor
def globals():
    return {"logged_in":user() is not None,"language":session.get("language","en")}

@app.route("/")
def index():
    u=user()
    if not u:return redirect(url_for("login"))
    return render_template("index.html",user=u,level=level(u["points"]),progress=progress(u["points"]))

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        name=request.form.get("username","").strip()
        if name:
            c=db()
            if not c.execute("SELECT id FROM users WHERE username=?",(name,)).fetchone():
                c.execute("INSERT INTO users(username) VALUES(?)",(name,)); c.commit()
            c.close(); session["username"]=name
            return redirect(url_for("index"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/language/<lang>")
def language(lang):
    if lang in ("en","es"):session["language"]=lang
    return redirect(request.referrer or url_for("index"))

@app.route("/tasks")
def tasks():
    u=user()
    if not u:return redirect(url_for("login"))
    left=[t for t in TASKS if t["id"] not in completed(u["id"])]
    task=random.choice(left) if left else None
    session["current_task"]=task["id"] if task else None
    return render_template("tasks.html",user=u,task=task)

@app.route("/complete-task",methods=["POST"])
def complete_task():
    u=user()
    if not u:return redirect(url_for("login"))
    tid=session.get("current_task")
    task=next((t for t in TASKS if t["id"]==tid),None)
    if task:
        c=db()
        if not c.execute("SELECT 1 FROM completed_tasks WHERE user_id=? AND task_id=?",(u["id"],tid)).fetchone():
            c.execute("INSERT INTO completed_tasks VALUES(?,?)",(u["id"],tid))
            c.execute("UPDATE users SET points=points+?,completed_tasks=completed_tasks+1 WHERE id=?",(task["points"],u["id"]))
            c.commit()
        c.close()
    return redirect(url_for("tasks"))

@app.route("/profile")
def profile():
    u=user()
    if not u:return redirect(url_for("login"))
    return render_template("profile.html",user=u,level=level(u["points"]),progress=progress(u["points"]),next_level=next_level(u["points"]))

@app.route("/information")
def information():
    if not user():return redirect(url_for("login"))
    return render_template("information.html")

init_db()
if __name__=="__main__":app.run(debug=True)
